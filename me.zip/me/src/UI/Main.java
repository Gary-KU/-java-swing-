package UI;

import Utils.PathUtils;

import javax.imageio.ImageIO;
import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class Main extends JFrame {
    private JButton playButton, pauseButton, nextButton, prevButton, importButton ,shutdown;
    private JLabel currentTrackLabel;
    private JList<String> playlist;
    private DefaultListModel<String> playlistModel;
    private ArrayList<File> musicFiles;
    private Clip audioClip;
    private int currentTrackIndex = 0;
    private boolean isPlaying = false;
    private long pausedPosition = 0;  // 记录停止的变量
    private boolean send_Playcge=true;


    public void init() {
        setTitle("Gary Studio");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        //setIconImage();
        //窗口的焕发科技logo绘制
        try {
            setIconImage(ImageIO.read(new File(PathUtils.getRealPath("img.png"))));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        //ui绘制按钮的panel容器
        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(new FlowLayout());

        //生成几个按钮
        playButton = new JButton("Play");
        pauseButton = new JButton("Pause");
        nextButton = new JButton("Next");
        prevButton = new JButton("Previous");
        importButton = new JButton("Import Folder");
        shutdown = new JButton("shutdown");

        controlPanel.add(prevButton);
        controlPanel.add(playButton);
        controlPanel.add(pauseButton);
        controlPanel.add(nextButton);
        controlPanel.add(importButton);
        controlPanel.add(shutdown);

        //当前音乐
        currentTrackLabel = new JLabel("No track playing");
        currentTrackLabel.setHorizontalAlignment(SwingConstants.CENTER);

        //当前播放列表

        playlistModel = new DefaultListModel<>();
        playlist = new JList<>(playlistModel);
        JScrollPane playlistScrollPane = new JScrollPane(playlist);

        // 设置灰色背景
        playlist.setBackground(new Color(173, 216, 230, 128));
        playlist.setForeground(Color.black); // 可选：设置前景色为白色，以便在灰色背景上可见

        //音乐文件集合
        musicFiles = new ArrayList<>();

        //BorderLayout布局
        setLayout(new BorderLayout());
        add(currentTrackLabel, BorderLayout.NORTH);
        add(controlPanel, BorderLayout.SOUTH);
        add(playlistScrollPane, BorderLayout.CENTER);

        // 时间监听器
        importButton.addActionListener(e -> importMusicFromFolder());
        playButton.addActionListener(e -> playMusic());
        pauseButton.addActionListener(e -> pauseMusic());
        nextButton.addActionListener(e -> nextTrack());
        prevButton.addActionListener(e -> previousTrack());
        shutdown.addActionListener(e -> shutdownTrack());
        initializeMusicPath();

        //更新当前播放显示
        setVisible(true);
        updateTrackLabel();
    }

   //从文件夹里面取出播放文件
    private void importMusicFromFolder() {
        //使用java swing的选择项
        JFileChooser folderChooser = new JFileChooser();
        folderChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        folderChooser.setDialogTitle("Select a Folder");

        int returnValue = folderChooser.showOpenDialog(this);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File folder = folderChooser.getSelectedFile();
            File[] files = folder.listFiles((dir, name) -> name.toLowerCase().endsWith(".wav"));

            if (files != null) {
                for (File file : files) {
                    musicFiles.add(file);
                    playlistModel.addElement(file.getName());
                }
            }
        }
    }
    private void initializeMusicPath() {
        String specifiedDirectoryPath = "D:/music";
        File folder = new File(specifiedDirectoryPath);
        File[] files = folder.listFiles((dir, name) -> name.toLowerCase().endsWith(".wav"));

        if (files != null) {
            for (File file : files) {
                musicFiles.add(file);
                playlistModel.addElement(file.getName());
            }
        }
    }

     //音乐的播放
    private void playMusic() {
        if (musicFiles.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No music files in playlist. Please import files first.");
            return;
        }

        try {
            //1.音乐存在并且正在播放就退出
            if (audioClip != null && audioClip.isRunning()) {
              return;
            }

            //2.取得音乐
            File track = musicFiles.get(currentTrackIndex);
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(track);
            audioClip = AudioSystem.getClip();
            audioClip.open(audioStream);

            //3.暂停  暂停的时间大于零，并且暂停的信号量结束了
            if (pausedPosition > 0 && !send_Playcge ) {
                audioClip.setMicrosecondPosition(pausedPosition);// 恢复
                send_Playcge=true;
            }

            audioClip.start();
            isPlaying = true;
            updateTrackLabel();
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            JOptionPane.showMessageDialog(this, "Error playing file: " + e.getMessage());
        }
    }

    //暂停函数：
    private void pauseMusic() {
        if (audioClip != null && isPlaying) {
            pausedPosition = audioClip.getMicrosecondPosition();  // Save the current position
            audioClip.stop();
            isPlaying = false;
            send_Playcge=false;
        }
    }


    private void nextTrack() {
        if (musicFiles.isEmpty()) return;

        if (audioClip != null) {
            pausedPosition=0;
        }

        currentTrackIndex = (currentTrackIndex + 1) % musicFiles.size();
        playMusic();
    }

    private void previousTrack() {
        if (musicFiles.isEmpty()) return;

        if (audioClip != null) {
            pausedPosition=0;
        }

        currentTrackIndex = (currentTrackIndex - 1 + musicFiles.size()) % musicFiles.size();
        playMusic();
    }

    private void updateTrackLabel() {
        if (musicFiles.isEmpty()) {
            currentTrackLabel.setText("No track playing");
        } else {
            currentTrackLabel.setText("Playing: " + musicFiles.get(currentTrackIndex).getName());
            currentTrackLabel.setFont(new Font("San Francisco", Font.PLAIN, 15));
        }
    }

    private void shutdownTrack(){
        audioClip.stop();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
              new Main().init();

        });
    }
}