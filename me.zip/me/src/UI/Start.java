package UI;

import Utils.PathUtils;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;

public class Start extends JFrame {
    JLabel Currentine;
    JLabel Message;

    public Start() {
        setTitle("Gary Studio");
        setSize(800,600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        try {
            setIconImage(ImageIO.read(new File(PathUtils.getRealPath("img.png"))));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        setLocationRelativeTo(null);

        //显示欢迎界面
        Currentine = new JLabel("Gary Studio");
        //显示正在加载的信息
        Message=new JLabel("Don't worry, it's loading...");

        // 设置字体大小为24
        Currentine.setFont(new Font("San Francisco", Font.PLAIN, 45));
        Message.setFont(new Font("San Francisco", Font.PLAIN, 24));

        Currentine.setHorizontalAlignment(SwingConstants.CENTER);
        Message.setHorizontalAlignment(SwingConstants.CENTER);

        setLayout(new BorderLayout());
        add(Currentine,BorderLayout.NORTH);

        ImageIcon photoIcon = new ImageIcon("C:\\Users\\Gary\\IdeaProjects\\test01\\picture\\img.png"); // 替换为你的图片路径
        JLabel photoLabel = new JLabel(photoIcon);
        add(photoLabel, BorderLayout.CENTER);

        JProgressBar bar = new JProgressBar(JProgressBar.HORIZONTAL, 0, 100);
        bar.setStringPainted(true);
        bar.setBorderPainted(false);

        //创建底部的Box容器
        Box vbox = Box.createVerticalBox();


        //把进度条和提示信息装进去
        vbox.add(Message);
        vbox.add(Box.createVerticalStrut(20));
        vbox.add(bar);
        vbox.add(Box.createVerticalStrut(20));

        add(vbox,BorderLayout.SOUTH);
        setVisible(true);

        // 使用 SwingWorker 来更新进度条
        SwingWorker<Void, Integer> worker = new SwingWorker<Void, Integer>() {
            @Override
            protected Void doInBackground() throws Exception {
                for (int i = 0; i <= 100; i++) {
                    Thread.sleep(50);
                    publish(i);
                }
                return null;
            }

            @Override
            protected void process(java.util.List<Integer> chunks) {
                for (int value : chunks) {
                    bar.setValue(value);
                    if(value>60)
                        Message.setText("I'm f**ing quickly work!!!");
                }
            }

            @Override
            protected void done() {
                //JOptionPane.showMessageDialog(Start.this, "正在转跳到主程序页面");
                new Main().init(); // 假设 Main 是另一个 JFrame 类
                Start.this.dispose(); // 关闭当前窗口
            }
        };
        worker.execute();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Start());
    }

}
