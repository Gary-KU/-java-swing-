package Utils;

import java.io.File;

public class PathUtils {
    private  static  final String P_PATH="C:\\Users\\Gary\\IdeaProjects\\me\\images\\";

    public static String getRealPath(String relativePath){

        return P_PATH+relativePath;
    }
}
